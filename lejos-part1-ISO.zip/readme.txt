The quick way to setup the leJOS fork (with Gradle support) and RMIDifferentialPilot to work with webrover1 project.

get a blank microsd, delete all partitions (at least 2GB).
Create partition 1, fat32, 477mb.
Create partition 2, ext2, 600mb.
Use dd if=XXXX.iso of=/dev/XXXXXX to write the images 

It should boot into leJOS. Set up the WIFI (Use edimax 7811un) and ssh with root@ with no password to log in. If you updated DBusJava projects or ev3classes, you can update those jars manually in the /home/root/lejos/lib folder.

leJOS Fork latest code:
git://git.code.sf.net/u/ryanv78665/lejos u-ryanv78665-lejos


webrover1 webapp for EV3: https://github.com/rvanderwerf/webrover1.git



Questions contact @RyanVanderwerf on Twitter.
More info see my blog post http://rvanderwerf.blogspot.com
